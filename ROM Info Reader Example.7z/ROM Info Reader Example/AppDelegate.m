#import "AppDelegate.h"
#import "Lesminni/NSData_CRC.h"
#import "Lesminni/RomFile.h"
#import "Lesminni/RomFileReader.h"

@implementation AppDelegate

- (IBAction) openDirectory:(id)sender{
	NSOpenPanel *sourceDir = [NSOpenPanel openPanel];
	[sourceDir setAllowsMultipleSelection:FALSE];
	[sourceDir setCanChooseDirectories:YES];
	[sourceDir setCanChooseFiles:NO];
	[sourceDir setCanCreateDirectories:YES];
	if([sourceDir runModalForDirectory:nil file:nil] == NSFileHandlingPanelOKButton){
		[directoryPathField setStringValue:[sourceDir directory]];
		[self ListDirectory:[sourceDir directory]];
	}
	else return;
}

- (IBAction) directoryEntered:(id)sender{
//	[self ListDirectory:[directoryPathField stringValue]];
}

- (void) ListDirectory:(NSString *) dirPath{
	romsArray = [[[NSMutableArray alloc] init] retain];
	NSMutableString *path = [NSMutableString stringWithString:[directoryPathField stringValue]];

	NSArray *pathComponents;
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSDirectoryEnumerator *dirEnum = [fileManager enumeratorAtPath:dirPath];

	NSString *currentFilename;
	NSMutableArray *content = [[NSMutableArray alloc] init];

	NSMutableArray *fileTypes = [[NSMutableArray alloc] init];
	[fileTypes addObject:@"gb"];	// GameBoy / GameBoy Color
	[fileTypes addObject:@"gbc"];	// GameBoy Color
	[fileTypes addObject:@"smc"];	// Super Nintendo
	[fileTypes addObject:@"swc"];	// Super Nintendo
	[fileTypes addObject:@"078"];	// Super Nintendo

	while((currentFilename = [dirEnum nextObject])){
		if([fileTypes containsObject:[currentFilename pathExtension]]) [content addObject:currentFilename];
	}

	int i;
	int fileCount = [content count];
	for(i = 0; i < fileCount; i++){
		// Break apart the path to the file
		pathComponents = [NSArray arrayWithObjects: path, [content objectAtIndex:i], nil];
		NSString *fullPath = [NSString pathWithComponents:pathComponents];

		NSLog(@"Filename: %@", [content objectAtIndex:i]);

		RomFile *romObject = [[RomFile alloc] init];
		RomFileReader *metadataReader;
		metadataReader = [RomFileReader parseFile:fullPath];

		NSDictionary *metadata = [metadataReader valueForKey:@"metadata"];
		NSLog(@"GameTitle: %@", [metadata valueForKey:@"internalTitle"]);

		NSString *romColorType			= [metadata valueForKey:@"colorType"];
		NSString *romCountry			= [metadata valueForKey:@"country"];
		NSString *romFileCRC32			= [metadata valueForKey:@"fileCRC32"];
		NSString *romGameTitle			= [metadata valueForKey:@"internalTitle"];
		NSString *romLicense			= [metadata valueForKey:@"license"];
		NSString *romManufacture		= [metadata valueForKey:@"manufacture"];
		NSString *romMBitsSize			= [metadata valueForKey:@"romSize"];
		NSString *romSRAMSize			= [metadata valueForKey:@"SRAMSize"];
		NSString *romSuperGB			= [metadata valueForKey:@"superGB"];
		NSString *romVersion			= [metadata valueForKey:@"version"];

		[romObject setColor:			romColorType];		// Color
		[romObject setCountry:			romCountry];		// Country
		[romObject setFileCRC32:		romFileCRC32];		// File CRC32
		[romObject setInternalTitle:	romGameTitle];		// Game Title
		[romObject setLicense:			romLicense];		// License
		[romObject setManufacture:		romManufacture];	// Manufacture
		[romObject setRomSize:			romMBitsSize];		// ROM Size
		[romObject setSaveSize:			romSRAMSize];		// Save Size (SRAM)
		[romObject setSuperGameboy:		romSuperGB];		// Super GameBoy
		[romObject setVersion:			romVersion];		// Version
		[romObject setFullPath:			fullPath];			// Full Path
		[romObject setFilename:			currentFilename];	// Filename
		[tableArray addObject:			romObject];
		[romObject release];
	}

//	Sort the array alphabetically by the game title, so when we make our list it's in order
	NSMutableArray *listArray = [tableArray arrangedObjects];
	NSLog(@"Found %d ROMs.", [listArray count]);
	NSLog(@"Might Rename %d ROMs.", [[tableArray arrangedObjects] count]);

//	Make sure we have at least 1 rom, or return because there would be nothing to do
	if([listArray count] == 0) return;

	NSMutableString *romBunch = [[NSMutableString alloc] init];

	int allofthem = [romsArray count];
	for(i = 0; i < allofthem; i++){
		RomFile *currentRom = [listArray objectAtIndex:i];

		[romBunch appendString: [currentRom internalTitle]];
		[romBunch appendString: @"\t"];
		[romBunch appendString: [currentRom manufacture]];
		[romBunch appendString: @"\t"];
		[romBunch appendString: [currentRom fileCRC32]];
		[romBunch appendString: @"\t"];
		[romBunch appendString: [NSString stringWithFormat:@"%d", [currentRom fileSize]]];
		[romBunch appendString: @"\n"];
	}

	// Save File Dialog
	NSOpenPanel *sp = [NSOpenPanel openPanel];
	NSString *resultUrl;
	int fileDialogResult;
	int alertResult = NSAlertAlternateReturn;

	[sp setTitle: NSLocalizedString(@"Save List To...", @"")];
	[sp setPrompt: NSLocalizedString(@"Save", @"")];
	[sp setCanChooseDirectories:YES];
	[sp setCanChooseFiles:NO];
	[sp setCanCreateDirectories:YES];
	[sp setResolvesAliases:YES];

	do{
		alertResult = NSAlertAlternateReturn;
		fileDialogResult = [sp runModalForDirectory:nil file:nil];
		dirEnum = [[NSFileManager defaultManager] enumeratorAtPath:[sp directory]];
		if(![self directoryEmpty:dirEnum] && (fileDialogResult == NSOKButton)){
			alertResult = NSRunAlertPanel(NSLocalizedString(@"Export", @""), NSLocalizedString(@"Directory isn't empty, old files may be overwritten. Continue?", @""), NSLocalizedString(@"No", @""), NSLocalizedString(@"Yes", @""), nil);
		}
	}

	while((fileDialogResult == NSOKButton) && (alertResult == NSAlertDefaultReturn));
	if(fileDialogResult == NSOKButton){
		NSString *url = @"";
		url = [url stringByAppendingPathComponent:[sp directory]];
		resultUrl = [url stringByAppendingPathComponent:@"roms.txt"];
		NSLog(@"resultUrl: %@", resultUrl);
	}
	else return;

	NSLog(@"Trying to write to file");

	NSMutableString *writeStatus = [[NSMutableString alloc] init];
//	Try to write the file
	if([romBunch writeToFile:resultUrl atomically:NO]) [writeStatus setString:NSLocalizedString(@"Write was successfull!", @"")];
	else [writeStatus setString:NSLocalizedString(@"Write Failed!", @"")];

//	Tell the user what happened
	NSRunInformationalAlertPanel(NSLocalizedString(@"Status Of Save Operation", @""), writeStatus, NSLocalizedString(@"Ok", @""), nil, nil);

	NSLog(@"Done writing to file.");
	[writeStatus release];
	[content release];
	[fileTypes release];
	[romBunch release];
}

- (BOOL)directoryEmpty:(NSDirectoryEnumerator *)dEnum{
	NSString *filename;
	BOOL result = YES;
//	Check whether directory contains only hidden files => then it's regarded empty (LINUX/UNIX specific!)
	while((filename = [dEnum nextObject]) && result){
		result = [[filename substringToIndex:1] isEqualToString:@"."];
	}
	return result;
}

- (IBAction)renameFiles:(id)sender{
	NSMutableString *temp = [NSMutableString stringWithString:[filesText stringValue]];

	if(![temp length]) return;
	NSFileManager *fileManager = [NSFileManager defaultManager];


	NSMutableArray *renameArray = [tableArray arrangedObjects];
	unsigned int i, count = [renameArray count];
	for(i = 0; i < count; i++){
		RomFile *oldFile = [renameArray objectAtIndex:i];
		NSString *newPath = [[oldFile fullPath] stringByDeletingLastPathComponent];
		NSString *ext = [[oldFile fullPath] pathExtension];

		newPath = [newPath stringByAppendingPathComponent:[self formatRenameText:temp:FALSE:i]];
		newPath = [newPath stringByAppendingPathExtension:ext];

		int result = 0;
		if(![fileManager fileExistsAtPath:newPath]){
			result = [fileManager movePath:[oldFile fullPath] toPath:newPath handler:nil];
		}
		else{
			result = [fileManager movePath:[oldFile fullPath] toPath:[newPath stringByAppendingString:@".TMP_"] handler:nil];
			if(result) result = [fileManager movePath:[[oldFile fullPath] stringByAppendingString:@".TMP_"] toPath:newPath handler:nil];
		}
		if(!result) NSLog(@"Error Renaming");
//		if(!result) NSLog(@"Error Renaming %@ to %@\n",[oldFile fullPath], newPath);
	}
//	[renameFilesPanel performClose:self];
}

-(IBAction)filesUpdatePreview:(id)sender{
	NSMutableString *preTemp = [NSMutableString stringWithString:[filesText stringValue]];
	NSString *previewText = [self formatRenameText:preTemp:FALSE:0];
	NSLog(@"Preview: %@", previewText);
	[filesPreviewLabel setStringValue:previewText];
}

- (void)filesPreviewChanged:(NSNotification *)o_notification{
	[self filesUpdatePreview:self];
}

- (NSString*)formatRenameText:(NSString *)text:(BOOL)isDir:(unsigned int)index{
	NSMutableString *formatted = [NSMutableString stringWithString:text];
	RomFile *rom = nil;

//	if([[RomsController arrangedObjects] count]) song = [[RomsController arrangedObjects] objectAtIndex:index];
	NSMutableArray *formatArray = [tableArray arrangedObjects];
	if([formatArray count]) rom = [formatArray objectAtIndex:index];

	NSString *name = rom &&	[[rom internalTitle] length] ?	[rom internalTitle]: @"Unknown";
	NSString *manu = rom &&	[[rom manufacture] length] ?	[rom manufacture]: @"Unknown";
	NSString *colo = rom &&	[[rom color] length] ?			[rom color]: @"Unknown";
	NSString *crcx = rom &&	[[rom fileCRC32] length] ?		[rom fileCRC32]: @"Unknown";
	NSString *spgb = rom &&	[[rom superGameboy] length] ?	[rom superGameboy]: @"Unknown";
	NSString *vers = rom &&	[[rom version] length] ?		[rom version]: @"Unknown";
	NSString *coun = rom &&	[[rom country] length] ?		[rom country]: @"Unknown";
	NSString *size = rom &&	[[rom romSize] length] ?		[rom romSize]: @"Unknown";

	NSLog(@"Name: %@", name);
	NSLog(@"Vers: %@", vers);
	NSLog(@"Size: %@", size);

	[formatted replaceOccurrencesOfString:@"%v" withString:vers options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%m" withString:manu options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%c" withString:colo options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%x" withString:crcx options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%s" withString:spgb options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%j" withString:coun options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%z" withString:size options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	[formatted replaceOccurrencesOfString:@"%n" withString:name options:NSCaseInsensitiveSearch range:NSMakeRange(0,[formatted length])];
	NSLog(@"Formatted x: %@", formatted);

	NSCell *cell = [filesCaseButtons selectedCell];
	switch([cell tag]){
		case 0:
			break;
		case 1:
			[formatted setString:[formatted capitalizedString]];
			break;
		case 2:{
			if([formatted length] < 1) break;

			NSString *first = [formatted substringToIndex:1];
			[formatted setString:[formatted lowercaseString]];
			[formatted setString:[formatted substringFromIndex:1]];
			first = [first uppercaseString];
			[formatted insertString:first atIndex:0];
			break;
		}
		case 3:
			[formatted setString:[formatted lowercaseString]];
			break;
		case 4:
			[formatted setString:[formatted uppercaseString]];
			break;
		default:
			break;
	}

	int spaceSwitch = [filesSpaceSwitch state];
	switch(spaceSwitch){
		case NSOffState:
			break;
		case NSOnState:
			[formatted replaceOccurrencesOfString:@" " withString:@"_" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [formatted length])];
			break;
		default: break;
	}
	return formatted;
}

- (void) awakeFromNib{
	[NSApp activateIgnoringOtherApps:YES];
}

- (void) applicationDidFinishLaunching: (NSNotification *) aNotification{
	[window makeKeyAndOrderFront:nil];
}

- (void) windowWillClose: (NSNotification *) aNotification{
	[NSApp terminate:self];
}

@end
