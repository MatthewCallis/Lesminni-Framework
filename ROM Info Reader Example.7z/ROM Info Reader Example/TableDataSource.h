#import <Cocoa/Cocoa.h>

@interface TableDataSource : NSObject{
	NSMutableArray *romsArray;

	int count;
}

- (void) setArrayContents: (NSMutableArray *) contents;
- (int) getColumnCount;

- (int) numberOfRowsInTableView: (NSTableView *) aTableView;
- (id) tableView: (NSTableView *) aTableView objectValueForTableColumn: (NSTableColumn *) aTableColumn row: (int) rowIndex;

- (NSArray *) getRows;

@end
