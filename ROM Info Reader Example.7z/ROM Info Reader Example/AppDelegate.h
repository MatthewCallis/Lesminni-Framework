#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject{
	IBOutlet NSWindow *window;
//	IBOutlet NSTableView *table;
	IBOutlet NSTextField *directoryPathField;

	IBOutlet NSArrayController *RomsController;

	IBOutlet NSTableView *table;
	IBOutlet id tableArray;
//	IBOutlet NSButton *exportButton;

	IBOutlet NSMatrix *filesCaseButtons;
	IBOutlet NSTextField *filesPreviewLabel;
	IBOutlet NSTextField *filesText;
	IBOutlet NSButton *filesSpaceSwitch;

	NSString *currentDir;
	NSMutableArray *romsArray;
}

- (IBAction) openDirectory:(id)sender;
- (IBAction) directoryEntered:(id)sender;

- (void) ListDirectory:(NSString *) dirPath;

- (BOOL)directoryEmpty:(NSDirectoryEnumerator *) dEnum;
- (NSString*)formatRenameText:(NSString *)text:(BOOL)isDir:(unsigned int)index;

- (IBAction) renameFiles:(id)sender;
- (IBAction) filesUpdatePreview:(id)sender;
- (void) filesPreviewChanged:(NSNotification *)o_notification;

- (void) windowWillClose:(NSNotification *) aNotification;

@end
