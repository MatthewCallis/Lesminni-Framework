#import "TableDataSource.h"

@implementation TableDataSource

- (void) setArrayContents: (NSMutableArray *) contents{
	romsArray = [[NSMutableArray alloc] init];
	romsArray = contents;
}

- (int) getColumnCount{
	return count;
}

- (int) numberOfRowsInTableView: (NSTableView *) aTableView{
	return [romsArray count];
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex{
	NSString *rowNum = [NSString stringWithFormat:@"%d", rowIndex+1];
	NSString *columnName = [aTableColumn identifier];

//	NSLog(@"Name: %@", [[romsArray objectAtIndex:rowIndex] name]);
//	[[romsArray objectAtIndex:i] filecrc32];
//	[[romsArray objectAtIndex:i] manufacture];

//	if([columnName isEqualToString:@"number"]) return [NSString stringWithString:rowNum];
	if([columnName isEqualToString:@"gameTitle"]) return [[romsArray objectAtIndex:rowIndex] fileCRC32];
//	if([columnName isEqualToString:@"fileCRC32"]) return [[romsArray objectAtIndex:rowIndex] fileCRC32];
//	if([columnName isEqualToString:@"manufacture"]) return [[romsArray objectAtIndex:rowIndex] manufacture];
}

- (NSArray *)getRows{
	return romsArray;
}

@end
